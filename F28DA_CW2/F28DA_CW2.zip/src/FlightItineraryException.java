public class FlightItineraryException extends Exception {

	private static final long serialVersionUID = -4630591510236199827L;

	public FlightItineraryException(String message) {
		super(message);
	}
}
